![image](https://github.com/user-attachments/assets/639d7379-617b-440a-980d-c2f78a587e4d)
![image](https://github.com/user-attachments/assets/5b284b44-222f-4bea-a7c2-877eef41444e)
![image](https://github.com/user-attachments/assets/0c3bc434-7f91-4554-885f-4c354ae01892)
![image](https://github.com/user-attachments/assets/9a4d9a66-c16a-4d4f-902f-74074fe2c8bf)
Use famous iris flower dataset from sklearn.datasets to predict flower species using random forest classifier.

Measure prediction score using default n_estimators (10)
Now fine tune your model by changing number of trees in your classifer and tell me what best score you can get using how many trees
