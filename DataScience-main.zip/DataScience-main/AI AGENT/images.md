<img width="1655" height="722" alt="image" src="https://github.com/user-attachments/assets/235399bd-7719-46b6-afa1-58b3f977a69b" />


# Instructions
1. Chat trigger
2. Ai Agent
3. open Ai
4. simple memory


<img width="1989" height="859" alt="image" src="https://github.com/user-attachments/assets/41302d3b-7747-45e8-a887-8dd8eea3e885" />

# Instructions
1. Choose Google Drive->(2nd option)
2. Create Credentails from google console
3. Enable google drive api
4. Go to API and Services
5. Create a new Project
6. Create a credentials
7. click on OAuthScreen
8. Click on client and then create client
9. copy the url from n8n paste that in the redirect url in google console
10. Take the client id and secrete key and paste that in n8n
11. After that sign in with google
12. Choose google drive and operation is  download
13. choose pinecone and create credentials in the piinecode
14. and paste api of pinecone in tbe n8n
15. add openAi embeddings and also default data loader
16. seperate flow create a chat trigger
17. attach the ai agent
18. add the open ai model for ai agent
19. in tools add the pincode vector and embedding to that pinecode vector store
20. open chat and start asking the questions
